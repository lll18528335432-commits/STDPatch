from data_provider.data_factory import data_provider
from exp.exp_basic import Exp_Basic
from models import STDPatch
from utils.tools import EarlyStopping, adjust_learning_rate, visual
from utils.metrics import metric

import numpy as np
import torch
import torch.nn as nn
from torch import optim
import os
import time
import warnings
import math
from thop import profile
warnings.filterwarnings('ignore')

class Exp_Main(Exp_Basic):
    def __init__(self, args):
        super(Exp_Main, self).__init__(args)

    def _build_model(self):
        model_dict = {
            'STDPatch': STDPatch,
        }
        model = model_dict[self.args.model].Model(self.args).float()

        if self.args.use_multi_gpu and self.args.use_gpu:
            # 使用重新映射后的设备ID (0, 1, 2, ...)
            device_ids = getattr(self.args, 'data_parallel_device_ids', list(range(len(self.args.device_ids))))
            model = nn.DataParallel(model, device_ids=device_ids)
        return model

    def _get_data(self, flag):
        data_set, data_loader = data_provider(self.args, flag)
        return data_set, data_loader

    def _select_optimizer(self):
        # model_optim = optim.Adam(self.model.parameters(), lr=self.args.learning_rate)
        model_optim = optim.AdamW(self.model.parameters(), lr=self.args.learning_rate)
        return model_optim

    # # MSE criterion
    # def _select_criterion(self):
    #     criterion = nn.MSELoss()
    #     return criterion

    # MSE and MAE criterion
    def _select_criterion(self):
        mse_criterion = nn.MSELoss()
        mae_criterion = nn.L1Loss()
        return mse_criterion, mae_criterion
    def get_complexity(self,x):
        # 1. 建立模型并设为评估模式
        model = self._build_model().to(self.device)
        model.eval()

        
        # 3. 调用 thop 计算
        try:
            # profile 默认会打印每一层的细节，如果不想要细节可以设置 verbose=False
            macs, params = profile(model, inputs=(x,), verbose=False)
            
            print("\n" + "="*30)
            print(f">>> 模型名称: {self.args.model}")
            print(f">>> 参数量 (Params): {params / 1e6:.2f} M")
            print(f">>> 计算量 (MACs):   {macs / 1e9:.2f} G")
            print("="*30 + "\n")
            
            # 将结果存入 result.txt 方便写论文
            with open("complexity_result.txt", 'a') as f:
                f.write(f"Model: {self.args.model}, Params: {params/1e6:.2f}M, MACs: {macs/1e9:.2f}G\n")
                
        except Exception as e:
            print(f"复杂度计算失败: {e}")
        
        return params, macs
    def vali(self, vali_data, vali_loader, criterion, is_test = True):
        total_loss = []
        self.model.eval()
        with torch.no_grad():
            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(vali_loader):
                batch_x = batch_x.float().to(self.device)
                batch_y = batch_y.float()

                batch_x_mark = batch_x_mark.float().to(self.device)
                batch_y_mark = batch_y_mark.float().to(self.device)

                # decoder input
                dec_inp = torch.zeros_like(batch_y[:, -self.args.pred_len:, :]).float()
                dec_inp = torch.cat([batch_y[:, :self.args.label_len, :], dec_inp], dim=1).float().to(self.device)
                # encoder - decoder
                outputs = self.model(batch_x)
                f_dim = -1 if self.args.features == 'MS' else 0
                outputs = outputs[:, -self.args.pred_len:, f_dim:]
                batch_y = batch_y[:, -self.args.pred_len:, f_dim:].to(self.device)

                # if train, use ratio to scale the prediction
                if not is_test:
                    # CARD loss with weight decay
                    # self.ratio = np.array([max(1/np.sqrt(i+1),0.0) for i in range(self.args.pred_len)])

                    # Arctangent loss with weight decay
                    self.ratio = np.array([-1 * math.atan(i+1) + math.pi/4 + 1 for i in range(self.args.pred_len)])
                    self.ratio = torch.tensor(self.ratio).unsqueeze(-1).to('cuda')

                    pred = outputs*self.ratio
                    true = batch_y*self.ratio
                else:
                    pred = outputs#.detach().cpu()
                    true = batch_y#.detach().cpu()

                # pred = outputs.detach().cpu()
                # true = batch_y.detach().cpu()

                loss = criterion(pred, true)

                total_loss.append(loss.item())
        total_loss = np.average(total_loss)
        self.model.train()
        return total_loss

    def train(self, setting):
        train_data, train_loader = self._get_data(flag='train')
        vali_data, vali_loader = self._get_data(flag='val')
        test_data, test_loader = self._get_data(flag='test')

        path = os.path.join(self.args.checkpoints, setting)
        if not os.path.exists(path):
            os.makedirs(path)

        train_visual_path = os.path.join(f'./train_results/{self.args.data_path}', setting)
        if not os.path.exists(train_visual_path):
            os.makedirs(train_visual_path)

        time_now = time.time()

        train_steps = len(train_loader)
        early_stopping = EarlyStopping(patience=self.args.patience, verbose=True)

        model_optim = self._select_optimizer()
        # criterion = self._select_criterion() # For MSE criterion
        mse_criterion, mae_criterion = self._select_criterion()

        # # CARD's cosine learning rate decay with warmup
        # self.warmup_epochs = self.args.warmup_epochs

        # def adjust_learning_rate_new(optimizer, epoch, args):
        #     """Decay the learning rate with half-cycle cosine after warmup"""
        #     min_lr = 0
        #     if epoch < self.warmup_epochs:
        #         lr = self.args.learning_rate * epoch / self.warmup_epochs 
        #     else:
        #         lr = min_lr+ (self.args.learning_rate - min_lr) * 0.5 * \
        #             (1. + math.cos(math.pi * (epoch - self.warmup_epochs) / (self.args.train_epochs - self.warmup_epochs)))
                
        #     for param_group in optimizer.param_groups:
        #         if "lr_scale" in param_group:
        #             param_group["lr"] = lr * param_group["lr_scale"]
        #         else:
        #             param_group["lr"] = lr
        #     print(f'Updating learning rate to {lr:.7f}')
        #     return lr

        # train_times = [] # For computational cost analysis
        for epoch in range(self.args.train_epochs):
            iter_count = 0
            train_loss = []
            # train_time = 0 # For computational cost analysis

            self.model.train()
            epoch_time = time.time()
            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(train_loader):
                iter_count += 1
                model_optim.zero_grad()
                batch_x = batch_x.float().to(self.device)
               
                batch_y = batch_y.float().to(self.device)
                batch_x_mark = batch_x_mark.float().to(self.device)
                batch_y_mark = batch_y_mark.float().to(self.device)

                # decoder input
                dec_inp = torch.zeros_like(batch_y[:, -self.args.pred_len:, :]).float()
                dec_inp = torch.cat([batch_y[:, :self.args.label_len, :], dec_inp], dim=1).float().to(self.device)

                # encoder - decoder
                # temp = time.time() # For computational cost analysis
                outputs = self.model(batch_x)
                # train_time += time.time() - temp # For computational cost analysis
                f_dim = -1 if self.args.features == 'MS' else 0
                
                # 模型输出可能包含输入和预测，需要只取预测部分
                # 前面96为输入，后面才是预测
                if outputs.shape[1] > self.args.pred_len:
                    # 如果输出长度大于pred_len，说明包含了输入部分，需要跳过前96个时间步
                    outputs = outputs[:, 96:, f_dim:]  # 跳过前96个输入时间步，只取预测部分
                else:
                    outputs = outputs[:, -self.args.pred_len:, f_dim:]
                
                # 保存完整的batch_y用于可视化真实值（包含label_len和pred_len）
                batch_y_full = batch_y.clone()  # 保存完整的batch_y（包含label_len+pred_len）
                
                batch_y = batch_y[:, -self.args.pred_len:, f_dim:].to(self.device)
                
                if i == 0:
                    # 真实值：包含输入部分和预测部分（完整序列）
                    # 从batch_x获取输入部分，从batch_y_full获取完整的真实值序列
                    input_np = batch_x[0, :, f_dim:].detach().cpu().numpy()
                    # batch_y_full包含label_len和pred_len，我们需要获取完整的真实值序列
                    batch_y_vis = batch_y_full[0, :, f_dim:].detach().cpu().numpy()
                    
                    # 预测值：只包含预测部分
                    preds_np = outputs[0].detach().cpu().numpy()
                    
                    # 处理维度：如果是多变量，取最后一个特征维度
                    if input_np.ndim == 2:
                        input_np = input_np[:, -1] if input_np.shape[1] > 1 else input_np[:, 0]
                    if preds_np.ndim == 2:
                        preds_np = preds_np[:, -1] if preds_np.shape[1] > 1 else preds_np[:, 0]
                    
                    input_np = input_np.reshape(-1)
                    preds_np = preds_np.reshape(-1)
                    
                    # 确保preds_np的长度不超过pred_len（如果模型输出更长，截断）
                    if len(preds_np) > self.args.pred_len:
                        preds_np = preds_np[:self.args.pred_len]
                    elif len(preds_np) < self.args.pred_len:
                        # 如果预测长度不足，用NaN填充
                        preds_padded = np.full(self.args.pred_len, np.nan)
                        preds_padded[:len(preds_np)] = preds_np
                        preds_np = preds_padded
                    
                    # 获取真实值的预测部分（用于对比）
                    if batch_y_vis.ndim == 2:
                        true_pred_np = batch_y_vis[:, -1] if batch_y_vis.shape[1] > 1 else batch_y_vis[:, 0]
                        true_pred_np = true_pred_np.reshape(-1)
                    else:
                        true_pred_np = batch_y_vis.reshape(-1)
                    
                    # 真实值：拼接输入部分和预测部分的真实值
                    # 只取pred_len长度的真实值用于对比
                    true_pred_np = true_pred_np[-self.args.pred_len:] if len(true_pred_np) >= self.args.pred_len else true_pred_np
                    trues_np = np.concatenate((input_np, true_pred_np), axis=0)
                    
                    # 预测值：前面填充NaN，只显示预测部分
                    # 创建与真实值相同长度的数组，前面填充NaN，后面填充预测值
                    preds_full_np = np.full_like(trues_np, np.nan)
                    # 确保长度匹配
                    min_len = min(len(preds_np), len(preds_full_np) - len(input_np))
                    if min_len > 0:
                        preds_full_np[len(input_np):len(input_np)+min_len] = preds_np[:min_len]
                
                    visual(trues_np, preds_full_np, os.path.join(train_visual_path, f'epoch_{epoch + 1}.pdf'))
                # CARD loss with weight decay
                # self.ratio = np.array([max(1/np.sqrt(i+1),0.0) for i in range(self.args.pred_len)])
                # Arctangent loss with weight decay
                self.ratio = np.array([-1 * math.atan(i+1) + math.pi/4 + 1 for i in range(self.args.pred_len)])
                self.ratio = torch.tensor(self.ratio).unsqueeze(-1).to('cuda')

                outputs = outputs * self.ratio
                batch_y = batch_y * self.ratio

                

                loss = mae_criterion(outputs, batch_y)

                # loss = criterion(outputs, batch_y) # For MSE criterion

                train_loss.append(loss.item())

                if (i + 1) % 100 == 0:
                    print("\titers: {0}, epoch: {1} | loss: {2:.7f}".format(i + 1, epoch + 1, loss.item()))
                    speed = (time.time() - time_now) / iter_count
                    left_time = speed * ((self.args.train_epochs - epoch) * train_steps - i)
                    print('\tspeed: {:.4f}s/iter; left time: {:.4f}s'.format(speed, left_time))
                    iter_count = 0
                    time_now = time.time()

                loss.backward()
                model_optim.step()

            # train_times.append(train_time/len(train_loader)) # For computational cost analysis
            print("Epoch: {} cost time: {}".format(epoch + 1, time.time() - epoch_time))
            train_loss = np.average(train_loss)
            # vali_loss = self.vali(vali_data, vali_loader, criterion) # For MSE criterion
            # test_loss = self.vali(test_data, test_loader, criterion) # For MSE criterion
            vali_loss = self.vali(vali_data, vali_loader, mae_criterion, is_test=False)
            test_loss = self.vali(test_data, test_loader, mse_criterion)

            print("Epoch: {0}, Steps: {1} | Train Loss: {2:.7f} Vali Loss: {3:.7f} Test Loss: {4:.7f}".format(
                epoch + 1, train_steps, train_loss, vali_loss, test_loss))
            early_stopping(vali_loss, self.model, path)

            if early_stopping.early_stop:
                print("Early stopping")
                break

            adjust_learning_rate(model_optim, epoch + 1, self.args)
            # adjust_learning_rate_new(model_optim, epoch + 1, self.args)

            # print('Alpha:', self.model.decomp.ma.alpha) # Print the learned alpha
            # print('Beta:', self.model.decomp.ma.beta)   # Print the learned beta

        # print("Training time: {}".format(np.sum(train_times)/len(train_times))) # For computational cost analysis
        best_model_path = path + '/' + 'checkpoint.pth'
        self.model.load_state_dict(torch.load(best_model_path))
        os.remove(best_model_path)

        return self.model

    def test(self, setting, test=0):
        test_data, test_loader = self._get_data(flag='test')
        
        if test:
            print('loading model')
            self.model.load_state_dict(torch.load(os.path.join('./checkpoints/' + setting, 'checkpoint.pth')))

        preds = []
        trues = []
        folder_path = './test_results/' + setting + '/'+self.args.data_path
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)

        # test_time = 0 # For computational cost analysis
        self.model.eval()
        with torch.no_grad():
            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(test_loader):
                batch_x = batch_x.float().to(self.device)
                batch_y = batch_y.float().to(self.device)

                batch_x_mark = batch_x_mark.float().to(self.device)
                batch_y_mark = batch_y_mark.float().to(self.device)

                # decoder input
                dec_inp = torch.zeros_like(batch_y[:, -self.args.pred_len:, :]).float()
                dec_inp = torch.cat([batch_y[:, :self.args.label_len, :], dec_inp], dim=1).float().to(self.device)
                # encoder - decoder
                # temp = time.time() # For computational cost analysis
                outputs = self.model(batch_x)
                # test_time += time.time() - temp # For computational cost analysis

                f_dim = -1 if self.args.features == 'MS' else 0
                outputs = outputs[:, -self.args.pred_len:, f_dim:]
                batch_y = batch_y[:, -self.args.pred_len:, f_dim:].to(self.device)
                outputs = outputs.detach().cpu().numpy()
                batch_y = batch_y.detach().cpu().numpy()

                pred = outputs  # outputs.detach().cpu().numpy()  # .squeeze()
                true = batch_y  # batch_y.detach().cpu().numpy()  # .squeeze()

                preds.append(pred)
                trues.append(true)

                if i % 20 == 0:
                    input = batch_x.detach().cpu().numpy()
                    gt = np.concatenate((input[0, :, -1], pred[0, :, -1]), axis=0)
                    pd = np.concatenate((input[0, :, -1], true[0, :, -1]), axis=0)
                    visual(gt, pd, os.path.join(folder_path, str(i) + '.pdf'))
            
        # print("Inference time: {}".format(test_time/len(test_loader))) # For computational cost analysis
        preds = np.array(preds)
        trues = np.array(trues)
        # preds = np.concatenate(preds, axis=0) # without the "drop-last" trick
        # trues = np.concatenate(trues, axis=0) # without the "drop-last" trick

        preds = preds.reshape(-1, preds.shape[-2], preds.shape[-1])
        trues = trues.reshape(-1, trues.shape[-2], trues.shape[-1])

        # # result save
        # folder_path = './results/' + setting + '/'
        # if not os.path.exists(folder_path):
        #     os.makedirs(folder_path)

        mae, mse = metric(preds, trues)
        print('mse:{}, mae:{}'.format(mse, mae))
        f = open("result.txt", 'a')
        f.write(setting + "  \n")
        f.write('mse:{}, mae:{}'.format(mse, mae))
        f.write('\n')
        f.write('\n')
        f.close()

        # np.save(folder_path + 'metrics.npy', np.array([mae, mse, rmse, mape, mspe,rse, corr]))
        # np.save(folder_path + 'pred.npy', preds)
        # np.save(folder_path + 'true.npy', trues)
        # np.save(folder_path + 'x.npy', inputx)
        return