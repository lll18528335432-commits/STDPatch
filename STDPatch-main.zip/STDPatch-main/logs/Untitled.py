import torch
import torch.nn as nn
import torch.optim as optim
class ModalityDecomposition(nn.Module):
    def __init__(self, in_dim):
        super(ModalityDecomposition, self).__init__()
        self.linear = nn.Linear(in_dim, in_dim)
        self.norm = nn.LayerNorm(in_dim)  # 使用 LayerNorm 支持时间序列 (B, T, C)
        self.activation = nn.PReLU()

    def forward(self, x):
        """
        前向传播
        Args:
            x: 形状为 (B, T, C) 的时间序列，或 (B, C) 的特征向量
        Returns:
            处理后的特征，形状与输入相同
        """
        # Linear 层可以处理 (B, T, C) 或 (B, C)
        x = self.linear(x)
        # LayerNorm 在最后一个维度上归一化，支持 (B, T, C) 和 (B, C)
        x = self.norm(x)
        x = self.activation(x)
        return x
class FusionGlobalView(nn.Module):
    def __init__(self, in_dim, hidden_size):
        super(FusionGlobalView, self).__init__()
        self.layer = nn.Sequential(
            nn.Linear(in_dim, hidden_size),
            nn.Dropout(p=0.1),
            nn.ReLU(),

            nn.Linear(hidden_size, hidden_size // 8),
            nn.Dropout(p=0.1),
            nn.ReLU()
        )

    def forward(self, x):
        return self.layer(x)
class PrivateGlobalView(nn.Module):
    def __init__(self, in_dim, out_dim):
        super(PrivateGlobalView, self).__init__()
        self.layer = nn.Sequential(
            nn.Linear(in_dim, out_dim),
            nn.Dropout(p=0.1),
            nn.ReLU()
        )

    def forward(self, x):
        return self.layer(x)
class CLUBSample_group(nn.Module):
    def __init__(self, x_dim, y_dim, hidden_size=256):
        super(CLUBSample_group, self).__init__()
        self.p_mu = nn.Sequential(
            nn.Linear(x_dim, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, hidden_size),
            nn.ReLU(),
            nn.Linear( hidden_size, y_dim))

        self.p_logvar = nn.Sequential(
            nn.Linear(x_dim, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, y_dim),
            nn.Tanh())

    def get_mu_logvar(self, x_samples):
        mu = self.p_mu(x_samples)
        logvar = self.p_logvar(x_samples)
        return mu, logvar

    def loglikeli(self, x_samples, y_samples):
        mu, logvar = self.get_mu_logvar(x_samples)
        return (-(mu - y_samples) ** 2 / logvar.exp() - logvar).mean()

    def mi_est(self, x_samples, y_samples):
        mu, logvar = self.get_mu_logvar(x_samples)

        sample_size = y_samples.shape[0]
        random_index = torch.randperm(sample_size).long()

        positive = - (mu - y_samples) ** 2 / logvar.exp()
        negative = - (mu - y_samples[random_index]) ** 2 / logvar.exp()
        upper_bound = (positive.sum(dim=-1) - negative.sum(dim=-1)).mean()
        return upper_bound / 2.
class WeightNet(nn.Module):
    def __init__(self, in_dim):
        super(WeightNet, self).__init__()
        self.layer = nn.Sequential(
            nn.Linear(in_dim * 2, in_dim),
            nn.Dropout(p=0.1),
            nn.ReLU(),
            nn.Linear(in_dim, in_dim // 2),
            nn.Dropout(p=0.1),
            nn.ReLU(),
            nn.Linear(in_dim // 2, 1),
        )
    
    def forward(self, x):
        return self.layer(x)
class GCD_CMR(nn.Module):
    def __init__(self):
        super(GCD_CMR, self).__init__()
        
        
        # 确定模态维度：
        # - 优先使用 args.modality_dims（可自定义每个模态的维度）
        # - 否则使用 args.num_modalities，默认每模态 96 维
        
        
        num_modalities = 7
        if num_modalities is None:
            raise ValueError("请提供 args.modality_dims 或 args.num_modalities（默认每模态 96 维）")
        self.modality_dims = [96] * num_modalities

        # c 是模态数量
        self.num_modalities = len(self.modality_dims)
        
        # 计算拼接后的总维度
        self.concat_dim = sum(self.modality_dims)
        self.hidden_size = 256
        
        # 创建模态分解网络
        self.modality_decomposition = nn.ModuleList([ModalityDecomposition(dim) for dim in self.modality_dims])
        
        # 创建全局融合网络
        self.common_fusion = FusionGlobalView(self.concat_dim, self.hidden_size)
        
        # 创建私有全局视图网络
        self.private_global_view = nn.ModuleList([PrivateGlobalView(self.hidden_size // 8, dim) for dim in self.modality_dims])
        self.ln1=nn.Linear(1,96)
        # 动态创建所有两两模态的互信息网络（共 c*(c-1)/2 个）
        self.mi_nets = nn.ModuleDict()
        self.mi_optimizers = []
        for i in range(self.num_modalities):
            for j in range(i + 1, self.num_modalities):
                key = f'MI_{i}_{j}'
                self.mi_nets[key] = CLUBSample_group(self.modality_dims[i], self.modality_dims[j])
                optimizer = optim.Adam(
                    self.mi_nets[key].parameters(), 
                    lr= 1e-4, 
                    weight_decay=1e-5
                )
                self.mi_optimizers.append(optimizer)
        self.ln2=nn.Linear(96,1)
        # 创建权重网络
        self.weight_net = nn.ModuleList([WeightNet(dim) for dim in self.modality_dims])
    def forward(self, x_tensor, groundTruth_labels=None, training=True):
        """
        前向传播
        Args:
            x_tensor: 形状为 (B, T, C_total) 的时间序列张量
                      其中 C_total = sum(modality_dims)，最后一维按模态维度顺序拼接
                      - B: batch size (批次大小)
                      - T: time steps (时间步长)
                      - C_total: 全部模态拼接后的维度
            groundTruth_labels: 真实标签（可选）
            training: 是否为训练模式（可选）
        """
        # 验证输入
        
        expected_c = len(self.modality_dims)
        if x_tensor.shape[2] != expected_c:
            raise ValueError(f"特征维度应为 {expected_c}，但得到 {x_tensor.shape[2]}")
        x = x_tensor.unsqueeze(-1)
        x=self.ln1(x)
        # 按模态维度拆分为列表，供后续流程使用
        x_list = torch.unbind(x, dim=2)
        x_list=list(x_list)
        if training:
            self.features_MI_minimization(x_list)
        x_stack = torch.stack(x_list, dim=2) 
        x_stack=self.ln2(x_stack)
        x_stack=x_stack.squeeze(-1)
        return x_stack
    def features_MI_minimization(self, x_list):
        """
        最小化模态间的互信息
        Args:
            x_list: 长度为 c 的列表，每个元素是形状为 (B, T, C) 的时间序列张量
        """
        for circle_iter in range(1):
            # 获取批次大小和时间步长（假设所有模态的 B 和 T 相同）
            B, T = x_list[0].shape[0], x_list[0].shape[1]
            
            # 分解所有 c 个模态
            # 输入: (B, T, C) -> 输出: (B, T, C)
            primary_features = []
            for j in range(self.num_modalities):
                primary_feat = self.modality_decomposition[j](x_list[j])
                primary_features.append(primary_feat)

            # 拼接所有模态
            # x_list[j] 形状: (B, T, C_j)
            # 拼接后: (B, T, sum(C_j))
            global_view = torch.cat(x_list, dim=2)  # 在特征维度上拼接
            # 将 (B, T, sum(C_j)) reshape 为 (B*T, sum(C_j)) 以通过 Linear 层
            C = global_view.shape[2]
            global_view_flat = global_view.view(B * T, C)
            common_view_flat = self.common_fusion(global_view_flat)
            # 将结果 reshape 回 (B, T, hidden_size // 8)
            common_view = common_view_flat.view(B, T, -1)

            # 分离共享视图（保留梯度以训练 MI 网络）
            # common_view 形状: (B, T, hidden_size // 8)
            global_views = []
            for j in range(self.num_modalities):
                # 将 (B, T, hidden_size // 8) reshape 为 (B*T, hidden_size // 8)
                common_view_flat = common_view.view(B * T, -1)
                global_view_j_flat = self.private_global_view[j](common_view_flat)
                # reshape 回 (B, T, C_j)
                global_view_j = global_view_j_flat.view(B, T, -1)
                global_views.append(global_view_j)

            # 计算所有两两模态的互信息损失
            # 对于时间序列，我们需要对每个时间步计算 MI，然后平均
            # 先清零所有优化器的梯度
            for opt in self.mi_optimizers:
                opt.zero_grad()

            mi_loss_total = 0.0
            for i_idx in range(self.num_modalities):
                for j_idx in range(i_idx + 1, self.num_modalities):
                    key = f'MI_{i_idx}_{j_idx}'
                    # global_views[i_idx] 形状: (B, T, C_i)
                    # 将时间步展平: (B*T, C_i)
                    view_i_flat = global_views[i_idx].view(B * T, -1)
                    view_j_flat = global_views[j_idx].view(B * T, -1)
                    
                    lld_loss = -self.mi_nets[key].loglikeli(view_i_flat, view_j_flat)
                    mi_loss_total = mi_loss_total + lld_loss

            # 统一反向传播一次
            mi_loss_total.backward()

            # 优化器步骤
            for opt in self.mi_optimizers:
                opt.step()
                opt.zero_grad()

            # 将共享视图与主要模态拼接
            # global_views[j] 形状: (B, T, C_j), primary_features[j] 形状: (B, T, C_j)
            input_features = []
            for j in range(self.num_modalities):
                # 在特征维度上拼接: (B, T, 2*C_j)
                input_f = torch.cat([global_views[j], primary_features[j]], dim=2)
                input_features.append(input_f)

            # 计算权重
            weights = []
            for j in range(self.num_modalities):
                # input_features[j] 形状: (B, T, 2*C_j)
                # 将 (B, T, 2*C_j) reshape 为 (B*T, 2*C_j)
                input_f_flat = input_features[j].view(B * T, -1)
                weight_flat = self.weight_net[j](input_f_flat)  # (B*T, 1)
                # reshape 回 (B, T, 1)
                weight = weight_flat.view(B, T, 1)
                weights.append(weight)

            # 计算循环senti特征
            # primary_features[j] 形状: (B, T, C_j), weights[j] 形状: (B, T, 1)
            circle_senti_features = []
            for j in range(self.num_modalities):
                circle_senti = primary_features[j] * weights[j]  # 广播: (B, T, C_j) * (B, T, 1)
                circle_senti_features.append(circle_senti)

            # 更新模态
            for j in range(self.num_modalities):
                x_list[j] = x_list[j] - circle_senti_features[j]
