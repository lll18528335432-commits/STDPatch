import torch
from torch import nn
import numpy as np
from pykalman import KalmanFilter
from layers.ema import EMA
from layers.dema import DEMA
from scipy.signal import savgol_coeffs
import torch.nn.functional as C
import math
import os
from utils.tools import visual
class KalmanSmoother(nn.Module):
    """
    使用 PyTorch 实现的简化一阶 Kalman 滤波器，用于平滑时间序列。
    输入: (B, T, F) 的张量。
    输出: 同 shape 的平滑结果。
    """
    def __init__(self, process_var=1e-5, measure_var=1e-2):
        super().__init__()
        self.q = process_var  # 过程噪声协方差
        self.r = measure_var  # 观测噪声协方差

    def forward(self, x):
        B, T, F = x.shape
        device = x.device

        # 初始化变量
        x_hat = torch.zeros(B, T, F, device=device)
        P = torch.zeros(B, F, device=device)
        x_hat[:, 0, :] = x[:, 0, :]  # 初始估计值
        P[:, :] = 1.0                # 初始协方差

        for t in range(1, T):
            # 预测
            x_pred = x_hat[:, t-1, :]
            P_pred = P + self.q

            # 更新
            K = P_pred / (P_pred + self.r)
            x_hat[:, t, :] = x_pred + K * (x[:, t, :] - x_pred)
            P = (1 - K) * P_pred

        return x_hat
def fit_period_dictionary(x, S):
    """
    x: [B, T, C]
    S: candidate period
    returns:
      dictionary: [B, S, C]
      reconstructed_periodic: [B, P*S, C]
      residual: [B, P*S, C]
      P: number of periods
    """
    B, T, C = x.shape
    P = T // S
    if P < 1:
        raise ValueError("S too large for T")
    x_cut = x[:, :P*S, :].reshape(B, P, S, C)
    dictionary = x_cut.mean(dim=1)  # 平均得到周期模板
    reconstructed = dictionary.unsqueeze(1).repeat(1, P, 1, 1).reshape(B, P*S, C)
    residual = x[:, :P*S, :] - reconstructed
    return dictionary, reconstructed, residual, P


def mdl_score_from_residual(residual, k):
    """
    residual: [B, N, C]
    k: 参数数量
    returns: MDL per-batch tensor of shape [B]
    """
    B, N, C = residual.shape
    sigma2 = residual.pow(2).mean(dim=(1,2)) + 1e-12
    Npoints = N * 1.0
    loglik = -0.5 * Npoints * (torch.log(2 * math.pi * sigma2) + 1.0)
    neg_loglik = -loglik
    penalty = 0.5 * k * math.log(Npoints)
    mdl = neg_loglik + penalty
    return mdl


def greedy_mdl_period_detection(x, S_candidates, max_periods=3, mdl_threshold=0.0,device=None):
    """
    x: [B, T, C]
    自动选择最优周期组合，基于 MDL 原则
    """
    x = x.to(device)
    x_work = x.clone()
    B, T, C = x.shape
    selected = []
    mdl_history = []

    # baseline（无周期模型）
    baseline_sigma2 = x_work.pow(2).mean(dim=(1,2)) + 1e-12
    Nfull = T
    baseline_loglik = -0.5 * Nfull * (torch.log(2*math.pi*baseline_sigma2) + 1.0)
    baseline_mdl = -baseline_loglik

    for _iter in range(max_periods):
        best_gain = torch.zeros(B, device=device) - float('inf')
        best_choice = None
        best_outputs = None

        for S in S_candidates:
            if S > T:
                continue
            try:
                dictionary, reconstructed, residual, P = fit_period_dictionary(x_work, S)
            except Exception:
                continue
            Npoints = P * S
            k = S * C
            mdl = mdl_score_from_residual(residual, k)
            # baseline MDL for current segment
            sigma2_before = x_work[:, :P*S, :].pow(2).mean(dim=(1,2)) + 1e-12
            mdl_before = 0.5 * Npoints * (torch.log(2*math.pi*sigma2_before) + 1.0)
            gain = mdl_before - mdl  # positive = improvement
            avg_gain = gain.mean()
            if best_choice is None or avg_gain > best_gain.mean():
                best_choice = S
            
                best_outputs = (dictionary, reconstructed, residual, mdl, gain)
                best_gain = gain

        if best_choice is None:
            break

        dictionary, reconstructed, residual, mdl_vals, gain_vals = best_outputs
        accept_mask = gain_vals > mdl_threshold
        if accept_mask.sum() == 0:
            break

        # subtract accepted periodic part
        for b in range(B):
            if accept_mask[b]:
                x_work[b, :reconstructed.shape[1], :] -= reconstructed[b]

        selected.append((best_choice, dictionary, reconstructed, accept_mask))
        mdl_history.append(gain_vals.mean().item())

    return selected, x_work, mdl_history


def denoise_residual_soft_threshold(residual, window=21, factor=1.0):
    """
    CUDA 实现的局部方差软阈去噪，支持多通道输入。
    residual: [B, T, C]
    """
    B, N, C = residual.shape
    pad = window // 2

    # 交换维度 -> [B, C, N]
    res = residual.transpose(1, 2)

    # 使用 depthwise 卷积（每个通道独立处理）
    kernel = torch.ones(C, 1, window, device=residual.device) / window  # [C,1,K]

    res_pad = torch.nn.functional.pad(res, (pad, pad), mode='reflect')

    mean = torch.nn.functional.conv1d(res_pad, kernel, groups=C)
    sq_mean = torch.nn.functional.conv1d(res_pad**2, kernel, groups=C)
    local_std = torch.sqrt(torch.clamp(sq_mean - mean**2, min=1e-8))

    # 阈值
    thr = factor * local_std
    out = torch.sign(res) * torch.clamp(torch.abs(res) - thr, min=0.0)

    return out.transpose(1, 2)  # 回到 [B, T, C] # 回到 [B, N, C]
class SavitzkyGolayFilter(torch.nn.Module):
    def __init__(self, window_length: int = 95, polyorder: int = 2, deriv: int = 0):
        super().__init__()
        assert window_length % 2 == 1, "window_length must be odd"
        self.window_length = window_length
        self.polyorder = polyorder
        self.deriv = deriv

        coeffs = savgol_coeffs(window_length, polyorder, deriv, use='conv')
        self.register_buffer('kernel', torch.tensor(coeffs, dtype=torch.float32).view(1, 1, -1))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        输入: x.shape = (B, T, F)
        """
        B, T, F = x.shape
        x = x.permute(0, 2, 1)  # 转换为 (B, F, T)

        pad_len = self.window_length // 2

        # 【底层修复】：改用显式的 torch.cat 提取头尾端点向外复制拼接，完全等价于 mode='replicate'
        # x[:, :, :1] 提取时间轴第一个点，形状为 (B, F, 1)；通过 expand 复制 pad_len 次
        left_pad = x[:, :, :1].expand(-1, -1, pad_len)
        right_pad = x[:, :, -1:].expand(-1, -1, pad_len)
        x_padded = torch.cat([left_pad, x, right_pad], dim=-1) # 在时间轴 T 拼接

        # 执行组卷积
        x_smoothed = torch.nn.functional.conv1d(
            x_padded, 
            self.kernel.expand(F, -1, -1), 
            padding=0, 
            groups=F
        )

        return x_smoothed.permute(0, 2, 1)
'''
class SavitzkyGolayFilter(torch.nn.Module):
    def __init__(self, window_length: int = 23, polyorder: int = 2, deriv: int = 0):
        super().__init__()
        assert window_length % 2 == 1, "window_length must be odd"
        self.window_length = window_length
        self.polyorder = polyorder
        self.deriv = deriv

        coeffs = savgol_coeffs(window_length, polyorder, deriv, use='conv')
        self.register_buffer('kernel', torch.tensor(coeffs, dtype=torch.float32).view(1, 1, -1))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, T, F = x.shape
        x = x.permute(0, 2, 1)  # (B, F, T)
        x = torch.nn.functional.conv1d(x, self.kernel.expand(F, -1, -1), padding=self.window_length // 2, groups=F)
        return x.permute(0, 2, 1)'''
def compute_mdl(x, S):
    """
    计算给定周期 S 下的 MDL 得分
    x: [B, T, C] 时间序列
    """
    B, T, C = x.shape
    P = T // S  # 周期数
    if P < 2:
        return torch.inf  # 周期太大无法划分

    # === Step 1. 切分序列 ===
    x_reshaped = x[:, :P*S, :].reshape(B, P, S, C)

    # === Step 2. 拟合周期均值模型 ===
    seasonal_mean = x_reshaped.mean(dim=1, keepdim=True)  # [B, 1, S, C]
    residual = x_reshaped - seasonal_mean

    # === Step 3. 残差方差估计 ===
    sigma_sq = residual.pow(2).mean(dim=(1,2,3)) + 1e-8

    # === Step 4. 计算MDL ===
    num_data = P * S * C
    k = S * C  # 参数数量 = 每个时间点一个均值
    log_likelihood = -0.5 * num_data * torch.log(2 * math.pi * sigma_sq) - 0.5 * num_data
    complexity_penalty = 0.5 * k * math.log(num_data)
    mdl = -log_likelihood + complexity_penalty

    return mdl.mean()

def find_best_period(x, S_candidates):
    """
    搜索最优周期长度 S*
    """
    best_S, best_mdl = None, torch.inf
    for S in S_candidates:
        mdl = compute_mdl(x, S)
        if mdl < best_mdl:
            best_mdl, best_S = mdl, S
    return best_S, best_mdl.item()

class DECOMP(nn.Module):
    """
    Series decomposition block
    """
    def __init__(self, ma_type, alpha, beta):
        super(DECOMP, self).__init__()
        self.kern=KalmanSmoother(1e-5,1e-2)
        self.sep=SavitzkyGolayFilter(window_length=23,polyorder=2)
        self.sep1=SavitzkyGolayFilter(window_length=7, polyorder=2)
        if ma_type == 'ema':
            self.ma = EMA(alpha)
        elif ma_type == 'dema':
            self.ma = DEMA(alpha, beta)
       
    def forward(self, x):
        
        moving_average = self.sep(x)
        res = x - moving_average
        S_candidates = [2,4,8,12, 24, 48, 72]
        device=x.device
        '''selected, residual, history = greedy_mdl_period_detection(x, S_candidates, max_periods=3, mdl_threshold=1e-3,device=device)
        
        # reconstruct periodic sum
        recon_sum = torch.zeros_like(x)
        for S, dicti, recon, mask in selected:
            # For batches with acceptance, add their recon back
            recon_sum[:, :recon.shape[1], :] += recon  # some batches not accepted are zeroed in x_work

        # denoise residual
        # residual currently is x minus accepted periodic parts
        denoised_res = denoise_residual_soft_threshold(residual, window=11, factor=1.0)

        final_recon = recon_sum + denoised_res'''
        
        if not hasattr(self, '_saved_plots'):
            save_dir = './decomp_results'
            os.makedirs(save_dir, exist_ok=True)
            sample_x = x[0].detach().cpu().numpy()
            sample_res = res[0].detach().cpu().numpy()
            sample_ma = moving_average[0].detach().cpu().numpy()
            if sample_x.ndim == 2:
                sample_x = sample_x[:, 0]
            if sample_res.ndim == 2:
                sample_res = sample_res[:, 0]
            if sample_ma.ndim == 2:
                sample_ma = sample_ma[:, 0]
            sample_x = sample_x.reshape(-1)
            sample_res = sample_res.reshape(-1)
            sample_ma = sample_ma.reshape(-1)
            visual(sample_x, name=os.path.join(save_dir, 'x.pdf'))
            visual(sample_res, name=os.path.join(save_dir, 'res.pdf'))
            visual(sample_ma, name=os.path.join(save_dir, 'moving_average.pdf'))
            self._saved_plots = True

        return res, moving_average