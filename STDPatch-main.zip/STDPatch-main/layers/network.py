import math
import torch
from torch import nn
import numpy as np 
import math 
import torch.nn.functional as F 
from statsmodels.tsa.stattools import acf, pacf
from layers.Embed import DataEmbedding_inverted
from layers.Transformer_EncDec import Encoder, EncoderLayer
import matplotlib.pyplot as plt
import cupy as cp
class LearnableThreshold(nn.Module):
    def __init__(self, init_value=0.2):
        super().__init__()
        self.bias = nn.Parameter(torch.tensor(init_value))

    def forward(self, sim):
        """
        sim: (B,)
        return: threshold (scalar)
        """
        # 自适应阈值：mean + learnable bias
        return sim.mean() + self.bias
        #return torch.sigmoid(10 * (sim - self.threshold))
def mask_mean_std(sim, alpha=0.5):
    mean = sim.mean()
    std = sim.std(unbiased=False)
    thr = mean - alpha * std
    return (sim >= thr).float().unsqueeze(-1)
def mask_quantile(sim, q=0.7):
    thr = torch.quantile(sim, q)
    return (sim >= thr).float().unsqueeze(-1)
def mask_soft_to_hard(sim, temperature=10.0):
    soft = torch.sigmoid(temperature * (sim - sim.mean()))
    return (soft >= 0.5).float().unsqueeze(-1)
class MaskLearnableHard(nn.Module):
    def __init__(self, init_value=0.0):
        super().__init__()
        self.bias = nn.Parameter(torch.tensor(init_value))

    def forward(self, sim):
        thr = sim.mean() + self.bias
        return (sim >= thr).float().unsqueeze(-1)

class MaskAndNormalizeBySimilarity_prev(nn.Module):
    def __init__(
        self,
        mode="learnable",   # mean_std | quantile | soft_hard | learnable
        alpha=0.7,
        q=0.2,
        temperature=10.0
    ):
        super().__init__()
        self.mode = mode
        self.alpha = alpha
        self.q = q
        self.temperature = temperature

        if mode == "learnable":
            self.mask_layer = MaskLearnableHard(init_value=0.2)

    def forward(self, x):
        B, p, s = x.shape
        outputs = []

        for i in range(p - 1):
            xi = x[:, i, :]
            xip1 = x[:, i + 1, :]

            sim = F.cosine_similarity(xi, xip1, dim=-1)
           
            # ===== hard mask（相似度低的直接置 0）=====
            if self.mode == "mean_std":
                mask = mask_mean_std(sim, self.alpha)

            elif self.mode == "quantile":
                mask = mask_quantile(sim, self.q)

            elif self.mode == "soft_hard":
                mask = mask_soft_to_hard(sim, self.temperature)

            elif self.mode == "learnable":
                mask = self.mask_layer(sim)

            else:
                raise ValueError(f"Unknown mode: {self.mode}")

            # 🔴 低相似度样本直接清零
            xi_masked = xi * mask
            xi_norm =xi_masked

            outputs.append(xi_norm)

        outputs.append(x[:, -1, :])
        return torch.stack(outputs, dim=1)

class MaskAndNormalizeBySimilarity_next(nn.Module):
    def __init__(
        self,
        mode="learnable",   # mean_std | quantile | soft_hard | learnable
        alpha=0.7,
        q=0.2,
        temperature=10.0
    ):
        super().__init__()
        self.mode = mode
        self.alpha = alpha
        self.q = q
        self.temperature = temperature

        if mode == "learnable":
            self.mask_layer = MaskLearnableHard(init_value=0.2)

    def forward(self, x):
        B, p, s = x.shape
        outputs = []

        for i in range(p - 1):
            xi = x[:, i+1, :]
            xip1 = x[:, i, :]

            sim = F.cosine_similarity(xi, xip1, dim=-1)

            # ===== hard mask（相似度低的直接置 0）=====
            if self.mode == "mean_std":
                mask = mask_mean_std(sim, self.alpha)

            elif self.mode == "quantile":
                mask = mask_quantile(sim, self.q)

            elif self.mode == "soft_hard":
                mask = mask_soft_to_hard(sim, self.temperature)

            elif self.mode == "learnable":
                mask = self.mask_layer(sim)

            else:
                raise ValueError(f"Unknown mode: {self.mode}")

            # 🔴 低相似度样本直接清零
            xi_masked = xi * mask
            xi_norm = xi_masked

            outputs.append(xi_norm)

        outputs.append(x[:, -1, :])
        return torch.stack(outputs, dim=1)


class SimpleAttention(nn.Module):
    """简单的多头注意力适配器，用于 Transformer_EncDec"""
    def __init__(self, d_model, n_heads=8, dropout=0.1):
        super(SimpleAttention, self).__init__()
        self.d_model = d_model
        self.n_heads = n_heads
        self.d_k = d_model // n_heads
        
        self.w_qs = nn.Linear(d_model, d_model)
        self.w_ks = nn.Linear(d_model, d_model)
        self.w_vs = nn.Linear(d_model, d_model)
        self.fc = nn.Linear(d_model, d_model)
        
        self.dropout = nn.Dropout(dropout)
        self.layer_norm = nn.LayerNorm(d_model)
        
    def forward(self, q, k, v, attn_mask=None, tau=None, delta=None, **kwargs):
        # q, k, v: [B, L, D]
        B, L, D = q.size()
        residual = q
        
        # Linear projections
        Q = self.w_qs(q).view(B, L, self.n_heads, self.d_k).transpose(1, 2)  # [B, H, L, d_k]
        K = self.w_ks(k).view(B, L, self.n_heads, self.d_k).transpose(1, 2)  # [B, H, L, d_k]
        V = self.w_vs(v).view(B, L, self.n_heads, self.d_k).transpose(1, 2)  # [B, H, L, d_k]
        
        # Scaled dot-product attention
        scores = torch.matmul(Q, K.transpose(-2, -1)) / math.sqrt(self.d_k)  # [B, H, L, L]
        
        if attn_mask is not None:
            scores = scores.masked_fill(attn_mask == 0, -1e9)
        
        attn = F.softmax(scores, dim=-1)
        attn = self.dropout(attn)
        
        context = torch.matmul(attn, V)  # [B, H, L, d_k]
        context = context.transpose(1, 2).contiguous().view(B, L, D)  # [B, L, D]
        
        output = self.fc(context)
        output = self.dropout(output)
        output = self.layer_norm(output + residual)
        
        return output, attn.mean(dim=1)  # 返回平均注意力权重
class Network(nn.Module):
    def __init__(self, seq_len, pred_len, patch_len, stride, padding_patch,c_in, d_model=64 ):
        super(Network, self).__init__()

        # Parameters
        self.pred_len = pred_len
        self.d_model = d_model

        # Non-linear Stream
        # Patching
        self.patch_len = patch_len
        self.stride = stride
        self.padding_patch = padding_patch
        self.dim = patch_len * patch_len
        self.patch_num = (seq_len - patch_len)//stride + 1
        if padding_patch == 'end': # can be modified to general case
            self.padding_patch_layer = nn.ReplicationPad1d((0, stride)) 
            self.patch_num += 1

        # Patch Embedding
        self.fc1 = nn.Linear(patch_len, self.dim)
        self.gelu1 = nn.GELU()
        self.bn1 = nn.BatchNorm1d(seq_len//self.stride)
        
        # CNN Depthwise
        self.conv1 = nn.Conv1d(self.patch_num, self.patch_num,
                               patch_len, patch_len, groups=self.patch_num)
        self.gelu2 = nn.GELU()
        self.bn2 = nn.BatchNorm1d(seq_len//self.stride)

        # Residual Stream
        self.fc2 = nn.Linear(self.dim, patch_len)

        # CNN Pointwise
        self.conv2 = nn.Conv1d(self.patch_num, self.patch_num, 1, 1)
        self.gelu3 = nn.GELU()
        self.bn3 = nn.BatchNorm1d(seq_len//self.stride)

        # Flatten Head
        self.flatten1 = nn.Flatten(start_dim=-2)
        self.fc3 = nn.Linear(self.patch_num * patch_len, pred_len * 2)
        self.gelu4 = nn.GELU()
        self.fc4 = nn.Linear(pred_len * 2, pred_len)

        # Linear Stream
        # MLP
        self.fc5 = nn.Linear(seq_len, pred_len * 4)
        self.avgpool1 = nn.AvgPool1d(kernel_size=2)
        self.ln1 = nn.LayerNorm(pred_len * 2)

        self.fc6 = nn.Linear(pred_len * 2, pred_len)
        self.avgpool2 = nn.AvgPool1d(kernel_size=2)
        self.ln2 = nn.LayerNorm(pred_len // 2)

        self.fc7 = nn.Linear(pred_len // 2, pred_len)

        # Streams Concatination
        self.fc8 = nn.Linear(pred_len * 2, pred_len)
        self.conv5 = nn.Conv1d(self.patch_num, self.patch_num, 3, 1,3//2)
        self.linear_prev = nn.Linear(self.stride, (self.patch_len-self.stride)//2)
        self.linear_next = nn.Linear(self.stride, (self.patch_len-self.stride)//2)
        self.mask_and_normalize_by_similarity_prev = MaskAndNormalizeBySimilarity_prev()
        self.mask_and_normalize_by_similarity_next = MaskAndNormalizeBySimilarity_next()
        # Transformer Encoders for up/down sequences
        # 用于上升和下降序列的嵌入层
        d_ff = 256  # FFN维度
        n_layers = 1  # Encoder层数
        n_heads = 4  # 注意力头数
        
        # 上升序列的Encoder
        self.encoder_up = Encoder(
            [
                EncoderLayer(
                    SimpleAttention(d_model, n_heads=n_heads, dropout=0.1),
                    d_model,
                    d_ff,
                    dropout=0.1,
                    activation="gelu",
                ) for _ in range(n_layers)
            ],
        )
        
        # 下降序列的Encoder
        self.encoder_down = Encoder(
            [
                EncoderLayer(
                    SimpleAttention(d_model, n_heads=n_heads, dropout=0.1),
                    d_model,
                    d_ff,
                    dropout=0.1,
                    activation="gelu",
                ) for _ in range(n_layers)
            ],
        )
        
        # Channel嵌入层：将C维特征转换为d_model维
        # 这里暂时设置为支持足够大的C值，实际运行时根据数据调整
        self.channel_embed = nn.Linear(1, d_model)
        self.channel_embed2 = nn.Linear(c_in, d_model)
        # 输出投影层
        self.up_output = nn.Linear(seq_len, pred_len)
        self.down_output = nn.Linear(seq_len, pred_len)
        self.fc9 = nn.Linear(d_model,c_in)
    
    def forward(self, s, t):
        # x: [Batch, Input, Channel]
        # s - seasonality
        # t - trend
        
        s = s.permute(0,2,1) # to [Batch, Channel, Input]
        
        # Get dimensions
        B = s.shape[0] # Batch size
        C = s.shape[1] # Channel size
        I = s.shape[2] # Input size
        
        # Channel split for channel independence on s
        s = torch.reshape(s, (B*C, I)) # [Batch and Channel, Input]
        
        # Transform t from [Batch, Input, Channel] to [Batch, Input, d_model]
        # t: [Batch, Input, Channel] -> [Batch*Input, Channel, 1] -> [Batch*Input, Channel, d_model] -> [Batch, Input, d_model]
        # 将每个channel独立embedding然后相加
        t_o=torch.reshape(t.permute(0,2,1), (B*C, I))
        t_reshaped = t.unsqueeze(-1)  # [B, I, C, 1]
        t_emb = self.channel_embed(t_reshaped)  # [B, I, C, d_model]
        # 对C个通道求和（而不是平均）
        t = t_emb.sum(dim=2)  # [B, I, d_model]'''
        
        #t=self.channel_embed2(t)
        # Now reshape t for processing (keep as B, I, d_model for now)


        
            
        s = s.unfold(dimension=-1, size=self.stride, step=self.stride)
        

         # 也可以用同一个线性层，看需求

        

        # 前一块、当前块、后一块
        x_prev = torch.zeros_like(s)
        x_next = torch.zeros_like(s)
        snew=self.mask_and_normalize_by_similarity_prev(s)
        # 前一块（第一块用自己）
        x_prev[:, 1:, :] = s[:, :-1, :]
        x_prev[:, 0, :] = s[:, 0, :]
        x_prev = self.mask_and_normalize_by_similarity_prev(x_prev)
        # 后一块（最后一块用自己）
        x_next[:, :-1, :] = s[:, 1:, :]
        x_next[:, -1, :] = s[:, -1, :]
        x_next = self.mask_and_normalize_by_similarity_next(x_next)
        # 压缩前后块
        prev_2 = self.linear_prev(x_prev)  # (B, 12, 2)
        
        curr_8 = s                   # (B, 12, 8)
        next_2 = self.linear_next(x_next)  # (B, 12, 2)

        # 拼接成12维
        s = torch.cat([prev_2, curr_8, next_2], dim=-1)  # (B, 12, 12)'''
        # s: [Batch and Channel, Patch_num, Patch_len]
        '''if self.padding_patch == 'end':
            s = self.padding_patch_layer(s)
            
        s = s.unfold(dimension=-1, size=self.patch_len, step=self.stride)
        Y=s.shape[1]'''
        
        # Patch Embedding
        s = self.fc1(s)
        s = self.gelu1(s)
        
        s = self.bn1(s)

        res = s

        # CNN Depthwise
        s = self.conv1(s)
        s = self.gelu2(s)
        s = self.bn2(s)
       
        # Residual Stream
        res = self.fc2(res)
        s = s + res

        # CNN Pointwise
        
        s = self.conv2(s)
        
        s = self.gelu3(s)
        s = self.bn3(s)

        # Flatten Head
        s = self.flatten1(s)
        
        s = self.fc3(s)
        s = self.gelu4(s)
        s = self.fc4(s)
        t_for_fc = t_o
        # Linear Stream - 使用 Transformer Encoder 处理上升和下降序列
        # t现在是 [B, I, d_model]，需要转换成 [B, I, 1] 来创建mask
        # 先对d_model维度求平均或求和来得到一个标量
        
        t_for_mask = t.mean(dim=-1)  # [B, I]
        
        # 计算差分并创建上升/下降掩码
        diff = torch.diff(t_for_mask, dim=1, prepend=t_for_mask[:, :1])  # (B, I)
        up_mask = (diff > 0).unsqueeze(-1).float()  # (B, I, 1)
        down_mask = (diff <= 0).unsqueeze(-1).float()  # (B, I, 1)
        #分别提取上升和下降序列
        x_up = t * up_mask  # (B, I, d_model)
        x_down = t * down_mask  # (B, I, d_model)
        
        # 通过 Transformer Encoder 处理
        x_up_encoded, _ = self.encoder_up(x_up)  # (B, I, d_model)
        x_down_encoded, _ = self.encoder_down(x_down)  # (B, I, d_model)
        
        # 全局平均池化或使用最后一个时间步
        # 使用全局平均池化：对序列长度维度求平均
        
        x_up_pooled = x_up_encoded.reshape(-1, I) # (B, d_model)
        x_down_pooled = x_down_encoded.reshape(-1, I)  # (B, d_model)
        # 投影到预测长度
        
        x_up_out = self.up_output(x_up_pooled)  # (B, pred_len)
        x_down_out = self.down_output(x_down_pooled)  # (B, pred_len)
        
        # 合并上升和下降序列的结果
        t_res = x_up_out + x_down_out  # (B, pred_len)
        # 对原始趋势序列使用线性层
        # t现在是[B, I, d_model]，需要转换成[B, I]来处理
        
        t_for_fc = self.fc5(t_for_fc)  # [B, pred_len*4]
       
        t_for_fc = self.avgpool1(t_for_fc)  # [B, 1, pred_len*2]
        
        t_for_fc = self.ln1(t_for_fc)

        t_for_fc = self.fc6(t_for_fc)  # [B, pred_len]
        
        t_for_fc = self.avgpool2(t_for_fc)  # [B, 1, pred_len//2]
        
        t_for_fc = self.ln2(t_for_fc)

        t_for_fc = self.fc7(t_for_fc)  # [B, pred_len]
        
        t_res=t_res.reshape(B, -1, self.pred_len).permute(0,2,1)
        
        t_res=self.fc9(t_res).permute(0,2,1).reshape(-1, self.pred_len)
        
        t = t_for_fc+t_res# (B, pred_len)
        
        # Streams Concatination
        # s是 (B*C, pred_len)，需要先reshape
        x = torch.cat((s, t), dim=1)  # [B, pred_len*2]
         # Channel concatination
        x = self.fc8(x)
        x = torch.reshape(x, (B, C, self.pred_len)) # [Batch, Channel, Output]

        x = x.permute(0,2,1) # to [Batch, Output, Channel]

        return x