import torch
import torch.nn as nn
import math
import numpy as np
from layers.decomp import DECOMP
from layers.network import Network

# from layers.network_mlp import NetworkMLP # For ablation study with MLP-only stream
# from layers.network_cnn import NetworkCNN # For ablation study with CNN-only stream
from layers.revin import RevIN

from models.Attention import EncoderLayer_selfattn
def get_conditon(x):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    x = x.to(device)
    
    x_g = x
    
    f_global = torch.fft.rfft(x_g[:, :, :-1], dim=-1)
    f_global = torch.cat((f_global.real, f_global.imag), dim=-1)

    emb_global = nn.Sequential(
        nn.Linear(96, 48),
        nn.Tanh(),
    ).to(device)
    f_global = emb_global(f_global)

    x_g = x_g.view(x.shape[0], 1, 1, -1)
    x_l = x_g.clone()
    x_l[:, :, :, -1] = 0

    unfold = nn.Unfold(
        kernel_size=(1, 16),
        dilation=1,
        padding=0,
        stride=(1, 16),
    ).to(device)

    unfold_x = unfold(x_l)
    unfold_x = unfold_x.transpose(1, 2)

    f_local = torch.fft.rfft(unfold_x, dim=-1)
    f_local = torch.cat((f_local.real, f_local.imag), dim=-1)

    emb_local = nn.Sequential(
        nn.Linear(2 + 16, 256),
        nn.Tanh(),
    ).to(device)
    f_local = emb_local(f_local)

    atten = nn.ModuleList([
        EncoderLayer_selfattn(
            256,
            512,
            8,
            512 // 8,
            512 // 8,
            dropout=0.1,
        ).to(device) for _ in range(1)
    ])

    for enc_layer in atten:
        f_local, enc_slf_attn = enc_layer(f_local)

    out_linear = nn.Sequential(
        nn.Linear(256, 96),
        nn.Tanh(),
    ).to(device)
    f_local = out_linear(f_local)
    f_local = f_local[:, -1, :].unsqueeze(1)

    #output = torch.cat((f_global, f_local), dim=-1)
    return f_local
def q_diffuse_whole_sequence(y0, beta_schedule, T_steps):
    """
    执行前向扩散：对整个长度为T的序列（作为单位）逐步加噪
    
    Args:
        y0: 原始序列 (batch_size, T, M)
        beta_schedule: Tensor 长度为 T_steps 的 beta 序列
        T_steps: 总扩散步骤数
        
    Returns:
        y_seq: List[y_t] from y_0 to y_T, 每项 shape 为 (batch_size, T, M)
    """
    device = y0.device
    y_seq = [y0]
    y_prev = y0
    
    for t in range(1, T_steps + 1):
        beta_t = beta_schedule[t - 1]
        sqrt_one_minus_beta = torch.sqrt(1 - beta_t)
        sqrt_beta = torch.sqrt(beta_t)
        noise = torch.randn_like(y_prev).to(device)
        
        y_t = sqrt_one_minus_beta * y_prev + sqrt_beta * noise
        y_seq.append(y_t)
        y_prev = y_t

    return y_seq
class Model(nn.Module):
    def __init__(self, configs):
        super(Model, self).__init__()

        # Parameters
        seq_len = configs.seq_len   # lookback window L
        pred_len = configs.pred_len # prediction length (96, 192, 336, 720)
        c_in = configs.enc_in       # input channels
        self.C=c_in
        self.S=configs.seq_len
        # Patching
        patch_len = configs.patch_len
        stride = configs.stride
        padding_patch = configs.padding_patch
        self.B=configs.batch_size
        # Normalization
        self.revin = configs.revin
        self.revin_layer = RevIN(c_in,affine=True,subtract_last=False)
        #self.net2= Network2(seq_len, pred_len, patch_len, stride, padding_patch)
        # Moving Average
        self.ma_type = configs.ma_type
        alpha = configs.alpha       # smoothing factor for EMA (Exponential Moving Average)
        beta = configs.beta         # smoothing factor for DEMA (Double Exponential Moving Average)
        self.fc8 = nn.Linear(pred_len * 2, pred_len)
        self.fc4=nn.Linear(2*c_in,c_in)
        self.decomp = DECOMP(self.ma_type, alpha, beta)
        self.net = Network(seq_len, pred_len, patch_len, stride, padding_patch,c_in)
        # self.net_mlp = NetworkMLP(seq_len, pred_len) # For ablation study with MLP-only stream
        # self.net_cnn = NetworkCNN(seq_len, pred_len, patch_len, stride, padding_patch) # For ablation study with CNN-only stream
    
    def forward(self, x):
        # x: [Batch, Input, Channel]
        
        
        batch_size = len(x)
        T = 20               # 输入序列长度
        feature_dim = 1     # 每个位置的特征维度
        T_steps = self.C      # 扩散步数
        
        '''x1= torch.randn(batch_size, self.S,T_steps)
        for i in range(T_steps):
            xi=x[:,:,i].reshape(batch_size,-1,1)
            beta_schedule = torch.linspace(1e-4, 0.02, 2)
            xi = q_diffuse_whole_sequence(xi, beta_schedule,1)
            
            xi=torch.stack(xi, dim=0).permute(3,2,1,0).reshape(batch_size,-1,2)
            if(i==0):
                x1=xi
            else:
                x1=torch.cat((x1,xi),dim=2)
        x1=self.fc4(x1)'''
        '''x_new = torch.zeros(self.B,1, self.S)
        x_new = x_new.to(x.device) 
        for i in range(self.C):
            x_i=x[:,:,i].reshape(len(x),1,-1)
            x_i = x_i.to(x_new.device) 
            x_i=get_conditon(x_i)
            
           
            
            if(i==0):
                x_new=x_i
            else:
                x_new=torch.cat([x_new,x_i],dim=1)
        x_new=x_new.permute(0,2,1)'''
        # Normalization
        if self.revin:
            x = self.revin_layer(x, 'norm')

        if self.ma_type == 'reg':   # If no decomposition, directly pass the input to the network
            x = self.net(x, x)
            # x = self.net_mlp(x) # For ablation study with MLP-only stream
            # x = self.net_cnn(x) # For ablation study with CNN-only stream
        else:
            seasonal_init, trend_init = self.decomp(x)
            
           
            
            x = self.net(seasonal_init, trend_init)
            
        '''x1 = self.net(x1, x1)'''
        # Denormalization
        if self.revin:
            x = self.revin_layer(x, 'denorm')
        
        '''x=torch.cat((x, x_new), dim=1)
        
        x = self.fc8(x.permute(0,2,1))
        x=x.permute(0,2,1)'''
        return x